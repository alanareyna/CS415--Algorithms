Contributors: Alana Reyna and Cody Grimes

ALANA CONTRIBUTIONS: Task1 A-C, Task3, main
CODY CONTRIBUTIONS: 2a, 2b
Instructions to run code:

enter "python main.py"
1. you will be prompted to enter a prefix for the file name ** NOTE: we do not specifically handle cases where an invalid prefix is entered, code will throw an error and immediately stop **
2. You should see the output for task1 and task2 for the file you entered
3. The program will continue to run and prompt you to enter more file prefix names
4. The program will stop if you enter "stop" exactly
5. The program will then output graphs for Task3 for the comparison of task1a and task1b as well as a graph for task1b vs task1c

IMPORTANT NOTES: Tasks 1 a-c work, along with 2.a.) 1.c's optimal set does not work. Very close to implementing 2.b)